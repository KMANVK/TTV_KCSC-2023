#include<bits/stdc++.h>

void ENC(int a1, int a2, int a3, int a4)
{
    int ret,tmp;
    ret = a1 + a2 + a3;
    tmp = (a4 + 0xA) ^ a1; 
    ret += tmp;
    ret = ret ^ a1; 
    printf("0x%x", ret);
}
int main()
{
    ENC(0xAB12DF34, 0x7B, 0x2D, 0x43);
    return 0;
}
#flag: KCSC{0xfd376061} 
